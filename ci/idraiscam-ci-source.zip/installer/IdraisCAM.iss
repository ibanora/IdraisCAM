#define MyAppName "IdraisCAM"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "IdraisCAM"

[Setup]
AppId={{B9C3F27F-4859-47A0-91E0-2A42E92B57D4}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={commonappdata}\obs-studio\plugins\idraiscam
DisableProgramGroupPage=yes
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir=..\dist
OutputBaseFilename=IdraisCAM-Setup-x64
Compression=lzma2
SolidCompression=yes
UninstallDisplayName=IdraisCAM OBS Plugin
CloseApplications=yes
RestartApplications=no

[Files]
Source: "..\release\idraiscam\bin\64bit\idraiscam.dll"; DestDir: "{commonappdata}\obs-studio\plugins\idraiscam\bin\64bit"; Flags: ignoreversion
Source: "..\release\idraiscam\data\locale\*"; DestDir: "{commonappdata}\obs-studio\plugins\idraiscam\data\locale"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\tools\connect-usb.bat"; DestDir: "{app}"; Flags: ignoreversion

[Dirs]
Name: "{commonappdata}\obs-studio\plugins\idraiscam\bin\64bit"
Name: "{commonappdata}\obs-studio\plugins\idraiscam\data\locale"

[Icons]
Name: "{autoprograms}\IdraisCAM USB"; Filename: "{app}\connect-usb.bat"

[Code]
function InitializeSetup(): Boolean;
begin
  Result := True;
  if FindWindowByWindowName('OBS Studio') <> 0 then
    MsgBox('Feche o OBS Studio antes de instalar o IdraisCAM.', mbInformation, MB_OK);
end;
