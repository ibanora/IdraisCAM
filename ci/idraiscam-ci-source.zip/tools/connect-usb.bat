@echo off
where adb >nul 2>nul
if errorlevel 1 (
  echo [ERRO] adb nao encontrado. Instale Android Platform Tools e adicione ao PATH.
  pause
  exit /b 1
)
adb devices
adb forward tcp:48484 tcp:48484
if errorlevel 1 (
  echo [ERRO] Nao foi possivel criar o encaminhamento USB.
  pause
  exit /b 1
)
echo IdraisCAM USB pronto em 127.0.0.1:48484
pause
