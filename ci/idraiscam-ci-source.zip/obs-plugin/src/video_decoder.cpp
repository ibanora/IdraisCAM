#include "video_decoder.hpp"
#include <obs-module.h>
#include <media-io/video-io.h>
#include <cstring>
extern "C" {
#include <libavcodec/avcodec.h>
#include <libavutil/frame.h>
#include <libavutil/imgutils.h>
#include <libswscale/swscale.h>
}

namespace idraiscam {
VideoDecoder::VideoDecoder() = default;
VideoDecoder::~VideoDecoder() { close(); }

bool VideoDecoder::open() {
    close();
    const AVCodec* decoder = avcodec_find_decoder(AV_CODEC_ID_H264);
    if (!decoder) return false;
    codec_ = avcodec_alloc_context3(decoder);
    if (!codec_) return false;
    codec_->flags2 |= AV_CODEC_FLAG2_FAST;
    codec_->thread_count = 1;
    codec_->pkt_timebase = AVRational{1, 1000000000};
    if (avcodec_open2(codec_, decoder, nullptr) < 0) { close(); return false; }
    frame_ = av_frame_alloc();
    return frame_ != nullptr;
}

void VideoDecoder::close() {
    if (sws_) sws_freeContext(sws_);
    sws_ = nullptr;
    if (converted_) av_frame_free(&converted_);
    if (frame_) av_frame_free(&frame_);
    if (codec_) avcodec_free_context(&codec_);
    convertedWidth_ = convertedHeight_ = 0;
}

void VideoDecoder::decode(const uint8_t* data, size_t size, uint64_t timestampNs, obs_source_t* source) {
    if (!codec_ && !open()) return;
    AVPacket* packet = av_packet_alloc();
    if (!packet) return;
    if (av_new_packet(packet, static_cast<int>(size)) < 0) { av_packet_free(&packet); return; }
    memcpy(packet->data, data, size);
    packet->pts = static_cast<int64_t>(timestampNs);
    packet->dts = packet->pts;
    if (avcodec_send_packet(codec_, packet) >= 0) {
        while (avcodec_receive_frame(codec_, frame_) == 0) outputFrame(frame_, timestampNs, source);
    }
    av_packet_free(&packet);
}

void VideoDecoder::outputFrame(AVFrame* f, uint64_t timestampNs, obs_source_t* source) {
    AVFrame* use = f;
    enum video_format obsFormat = VIDEO_FORMAT_NONE;
    if (f->format == AV_PIX_FMT_YUV420P || f->format == AV_PIX_FMT_YUVJ420P) {
        obsFormat = VIDEO_FORMAT_I420;
    } else if (f->format == AV_PIX_FMT_NV12) {
        obsFormat = VIDEO_FORMAT_NV12;
    } else {
        if (!converted_ || convertedWidth_ != f->width || convertedHeight_ != f->height) {
            if (converted_) av_frame_free(&converted_);
            converted_ = av_frame_alloc();
            converted_->format = AV_PIX_FMT_YUV420P;
            converted_->width = f->width;
            converted_->height = f->height;
            if (av_frame_get_buffer(converted_, 32) < 0) return;
            convertedWidth_ = f->width;
            convertedHeight_ = f->height;
        }
        sws_ = sws_getCachedContext(sws_, f->width, f->height, static_cast<AVPixelFormat>(f->format),
                                    f->width, f->height, AV_PIX_FMT_YUV420P, SWS_FAST_BILINEAR, nullptr, nullptr, nullptr);
        if (!sws_) return;
        av_frame_make_writable(converted_);
        sws_scale(sws_, f->data, f->linesize, 0, f->height, converted_->data, converted_->linesize);
        use = converted_;
        obsFormat = VIDEO_FORMAT_I420;
    }

    obs_source_frame out{};
    out.width = static_cast<uint32_t>(use->width);
    out.height = static_cast<uint32_t>(use->height);
    out.timestamp = timestampNs;
    out.format = obsFormat;
    out.full_range = f->color_range == AVCOL_RANGE_JPEG;
    for (int i = 0; i < MAX_AV_PLANES; ++i) {
        out.data[i] = use->data[i];
        out.linesize[i] = static_cast<uint32_t>(use->linesize[i] > 0 ? use->linesize[i] : 0);
    }
    const auto cs = (f->colorspace == AVCOL_SPC_BT470BG || f->colorspace == AVCOL_SPC_SMPTE170M) ? VIDEO_CS_601 : VIDEO_CS_709;
    video_format_get_parameters(cs, out.full_range ? VIDEO_RANGE_FULL : VIDEO_RANGE_PARTIAL,
                                out.color_matrix, out.color_range_min, out.color_range_max);
    obs_source_output_video(source, &out);
}
}
