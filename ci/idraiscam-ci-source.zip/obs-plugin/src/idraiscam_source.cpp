#include "idraiscam_source.hpp"
#include <media-io/audio-io.h>
#include <chrono>
#include <regex>
#include <thread>
#include <util/platform.h>

namespace idraiscam {

static int jsonInt(const std::string& json, const char* key, int fallback) {
    std::regex r(std::string("\\\"") + key + "\\\"\\s*:\\s*([0-9]+)");
    std::smatch m;
    return std::regex_search(json, m, r) ? std::stoi(m[1].str()) : fallback;
}

IdraisCamSource::IdraisCamSource(obs_source_t* source, obs_data_t* settings) : source_(source) {
    update(settings);
}

IdraisCamSource::~IdraisCamSource() { stop(); }

void IdraisCamSource::defaults(obs_data_t* settings) {
    obs_data_set_default_string(settings, "mode", "wifi");
    obs_data_set_default_string(settings, "device", "__manual__");
    obs_data_set_default_string(settings, "host", "127.0.0.1");
    obs_data_set_default_int(settings, "port", 48484);
}

void IdraisCamSource::update(obs_data_t* settings) {
    stop();
    mode_ = obs_data_get_string(settings, "mode");
    host_ = obs_data_get_string(settings, "host");
    port_ = static_cast<uint16_t>(obs_data_get_int(settings, "port"));

    const std::string device = obs_data_get_string(settings, "device");
    if (!device.empty() && device != "__manual__") {
        const auto sep = device.rfind(':');
        if (sep != std::string::npos) {
            host_ = device.substr(0, sep);
            try { port_ = static_cast<uint16_t>(std::stoi(device.substr(sep + 1))); } catch (...) {}
        }
    }
    if (mode_ == "usb") {
        host_ = "127.0.0.1";
        port_ = 48484;
    }
    start();
}

void IdraisCamSource::start() {
    if (running_.exchange(true)) return;
    worker_ = std::thread([this] { run(); });
}

void IdraisCamSource::stop() {
    running_.store(false);
    {
        std::lock_guard<std::mutex> lock(clientMutex_);
        if (client_) client_->close();
    }
    if (worker_.joinable()) worker_.join();
    {
        std::lock_guard<std::mutex> lock(clientMutex_);
        client_.reset();
    }
    decoder_.close();
}

void IdraisCamSource::run() {
    while (running_.load()) {
        if (mode_ == "usb" && !ensureAdbForward(port_)) {
            blog(LOG_WARNING, "[IdraisCAM] ADB USB forwarding failed. Ensure Android Platform Tools are installed and USB debugging is enabled.");
        }

        auto local = std::make_shared<TcpClient>();
        {
            std::lock_guard<std::mutex> lock(clientMutex_);
            client_ = local;
        }
        if (!local->connectTo(host_, port_)) {
            blog(LOG_DEBUG, "[IdraisCAM] Waiting for %s:%u", host_.c_str(), port_);
            std::this_thread::sleep_for(std::chrono::milliseconds(900));
            continue;
        }

        blog(LOG_INFO, "[IdraisCAM] Connected to %s:%u", host_.c_str(), port_);
        clockSynced_ = false;
        clockOffsetNs_ = 0;
        lastPingNs_ = 0;
        decoder_.open();
        Packet packet;
        while (running_.load() && local->receive(packet)) {
            process(packet);
            flushCommands(*local);
            const uint64_t now = os_gettime_ns();
            if (now - lastPingNs_ >= 5'000'000'000ULL) {
                local->send(PING, 0, 0, std::to_string(now));
                lastPingNs_ = now;
            }
        }
        local->close();
        decoder_.close();
        if (running_.load()) std::this_thread::sleep_for(std::chrono::milliseconds(500));
    }
}

void IdraisCamSource::process(const Packet& packet) {
    switch (packet.type) {
        case VIDEO_CONFIG:
        case VIDEO:
            if (!packet.payload.empty()) decoder_.decode(packet.payload.data(), packet.payload.size(), mapTimestamp(packet.timestamp_ns), source_);
            break;
        case AUDIO_CONFIG: {
            const std::string json(packet.payload.begin(), packet.payload.end());
            sampleRate_ = static_cast<uint32_t>(jsonInt(json, "sampleRate", 48000));
            channels_ = static_cast<uint32_t>(jsonInt(json, "channels", 1));
            if (channels_ != 2) channels_ = 1;
            break;
        }
        case AUDIO:
            outputAudio(packet);
            break;
        case HELLO: {
            const std::string hello(packet.payload.begin(), packet.payload.end());
            clockOffsetNs_ = static_cast<int64_t>(os_gettime_ns()) - static_cast<int64_t>(packet.timestamp_ns);
            clockSynced_ = true;
            blog(LOG_INFO, "[IdraisCAM] Android hello: %s", hello.c_str());
            break;
        }
        case PONG: {
            try {
                const std::string text(packet.payload.begin(), packet.payload.end());
                const uint64_t t0 = std::stoull(text);
                const uint64_t t2 = os_gettime_ns();
                const uint64_t midpoint = t0 + (t2 - t0) / 2;
                const int64_t estimate = static_cast<int64_t>(midpoint) - static_cast<int64_t>(packet.timestamp_ns);
                if (!clockSynced_) clockOffsetNs_ = estimate;
                else clockOffsetNs_ = (clockOffsetNs_ * 9 + estimate) / 10;
                clockSynced_ = true;
            } catch (...) {}
            break;
        }
        default:
            break;
    }
}

void IdraisCamSource::outputAudio(const Packet& packet) {
    if (packet.payload.empty()) return;
    obs_source_audio audio{};
    audio.data[0] = const_cast<uint8_t*>(packet.payload.data());
    audio.frames = static_cast<uint32_t>(packet.payload.size() / (2u * channels_));
    audio.speakers = channels_ == 2 ? SPEAKERS_STEREO : SPEAKERS_MONO;
    audio.samples_per_sec = sampleRate_;
    audio.format = AUDIO_FORMAT_16BIT;
    audio.timestamp = mapTimestamp(packet.timestamp_ns);
    obs_source_output_audio(source_, &audio);
}


uint64_t IdraisCamSource::mapTimestamp(uint64_t remoteNs) {
    if (!clockSynced_) {
        clockOffsetNs_ = static_cast<int64_t>(os_gettime_ns()) - static_cast<int64_t>(remoteNs);
        clockSynced_ = true;
    }
    const int64_t mapped = static_cast<int64_t>(remoteNs) + clockOffsetNs_;
    return mapped > 0 ? static_cast<uint64_t>(mapped) : os_gettime_ns();
}

void IdraisCamSource::enqueueControl(std::string json) {
    std::shared_ptr<TcpClient> client;
    {
        std::lock_guard<std::mutex> lock(clientMutex_);
        client = client_;
    }
    if (client && client->isConnected() && client->send(CONTROL, 0, 0, json)) return;
    std::lock_guard<std::mutex> lock(commandMutex_);
    commands_.push_back(std::move(json));
}

void IdraisCamSource::flushCommands(TcpClient& client) {
    std::vector<std::string> pending;
    {
        std::lock_guard<std::mutex> lock(commandMutex_);
        pending.swap(commands_);
    }
    for (const auto& command : pending) client.send(CONTROL, 0, 0, command);
}

static bool scanClicked(obs_properties_t* props, obs_property_t*, void*) {
    obs_property_t* list = obs_properties_get(props, "device");
    if (!list) return false;
    obs_property_list_clear(list);
    obs_property_list_add_string(list, obs_module_text("Manual"), "__manual__");
    const auto devices = discoverDevices(700);
    for (const auto& d : devices) {
        const std::string label = d.name.empty() ? d.host : d.name + " — " + d.host;
        const std::string value = d.host + ":" + std::to_string(d.port);
        obs_property_list_add_string(list, label.c_str(), value.c_str());
    }
    return true;
}


static bool startClicked(obs_properties_t*, obs_property_t*, void* data) {
    if (auto* self = static_cast<IdraisCamSource*>(data)) self->enqueueControl("{\"action\":\"start\"}");
    return false;
}

static bool stopClicked(obs_properties_t*, obs_property_t*, void* data) {
    if (auto* self = static_cast<IdraisCamSource*>(data)) self->enqueueControl("{\"action\":\"stop\"}");
    return false;
}

static bool switchClicked(obs_properties_t*, obs_property_t*, void* data) {
    if (auto* self = static_cast<IdraisCamSource*>(data)) self->enqueueControl("{\"action\":\"switchCamera\"}");
    return false;
}

static bool torchClicked(obs_properties_t*, obs_property_t*, void* data) {
    if (auto* self = static_cast<IdraisCamSource*>(data)) self->enqueueControl("{\"action\":\"torch\"}");
    return false;
}

IdraisCamSource* sourceFromData(void* data) { return static_cast<IdraisCamSource*>(data); }

obs_properties_t* IdraisCamSource::properties(void* data) {
    auto* props = obs_properties_create();
    auto* mode = obs_properties_add_list(props, "mode", obs_module_text("Connection"), OBS_COMBO_TYPE_LIST, OBS_COMBO_FORMAT_STRING);
    obs_property_list_add_string(mode, "Wi‑Fi / LAN", "wifi");
    obs_property_list_add_string(mode, "USB (ADB)", "usb");

    auto* device = obs_properties_add_list(props, "device", obs_module_text("Device"), OBS_COMBO_TYPE_LIST, OBS_COMBO_FORMAT_STRING);
    obs_property_list_add_string(device, obs_module_text("Manual"), "__manual__");
    obs_properties_add_button2(props, "scan", obs_module_text("ScanDevices"), scanClicked, nullptr);
    obs_properties_add_text(props, "host", obs_module_text("Host"), OBS_TEXT_DEFAULT);
    obs_properties_add_int(props, "port", obs_module_text("Port"), 1, 65535, 1);
    obs_properties_add_button2(props, "start_camera", obs_module_text("StartCamera"), startClicked, data);
    obs_properties_add_button2(props, "stop_camera", obs_module_text("StopCamera"), stopClicked, data);
    obs_properties_add_button2(props, "switch_camera", obs_module_text("SwitchCamera"), switchClicked, data);
    obs_properties_add_button2(props, "torch", obs_module_text("ToggleTorch"), torchClicked, data);
    return props;
}

}
