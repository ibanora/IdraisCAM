#pragma once
#include <cstdint>
#include <cstddef>
#include <vector>
struct obs_source;
typedef struct obs_source obs_source_t;
struct AVCodecContext;
struct AVFrame;
struct SwsContext;

namespace idraiscam {
class VideoDecoder {
public:
    VideoDecoder();
    ~VideoDecoder();
    bool open();
    void close();
    void decode(const uint8_t* data, size_t size, uint64_t timestampNs, obs_source_t* source);
private:
    AVCodecContext* codec_ = nullptr;
    AVFrame* frame_ = nullptr;
    AVFrame* converted_ = nullptr;
    SwsContext* sws_ = nullptr;
    int convertedWidth_ = 0;
    int convertedHeight_ = 0;
    void outputFrame(AVFrame* frame, uint64_t timestampNs, obs_source_t* source);
};
}
