#include "network.hpp"
#include <algorithm>
#include <array>
#include <chrono>
#include <cstring>
#include <regex>
#include <string>

#ifdef _WIN32
#include <ws2tcpip.h>
#include <windows.h>
#pragma comment(lib, "ws2_32.lib")
#else
#include <arpa/inet.h>
#include <netdb.h>
#include <netinet/tcp.h>
#include <sys/socket.h>
#include <unistd.h>
#define INVALID_SOCKET (-1)
#define SOCKET_ERROR (-1)
static void closesocket(int s) { ::close(s); }
#endif

namespace idraiscam {

static uint64_t ntoh64(uint64_t v) {
#if BYTE_ORDER == LITTLE_ENDIAN || defined(_WIN32)
    return (static_cast<uint64_t>(ntohl(static_cast<uint32_t>(v & 0xffffffffULL))) << 32) |
           ntohl(static_cast<uint32_t>(v >> 32));
#else
    return v;
#endif
}

static uint64_t hton64(uint64_t v) { return ntoh64(v); }

NetworkRuntime::NetworkRuntime() {
#ifdef _WIN32
    WSADATA data{};
    initialized_ = WSAStartup(MAKEWORD(2, 2), &data) == 0;
#else
    initialized_ = true;
#endif
}

NetworkRuntime::~NetworkRuntime() {
#ifdef _WIN32
    if (initialized_) WSACleanup();
#endif
}

TcpClient::TcpClient() : socket_(INVALID_SOCKET) {}
TcpClient::~TcpClient() { close(); }

bool TcpClient::connectTo(const std::string& host, uint16_t port) {
    close();
    addrinfo hints{};
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    addrinfo* result = nullptr;
    const auto portText = std::to_string(port);
    if (getaddrinfo(host.c_str(), portText.c_str(), &hints, &result) != 0) return false;
    for (auto* p = result; p; p = p->ai_next) {
        SOCKET s = ::socket(p->ai_family, p->ai_socktype, p->ai_protocol);
        if (s == INVALID_SOCKET) continue;
        if (::connect(s, p->ai_addr, static_cast<int>(p->ai_addrlen)) == 0) {
            socket_.store(s);
            int yes = 1;
            setsockopt(s, IPPROTO_TCP, TCP_NODELAY, reinterpret_cast<const char*>(&yes), sizeof(yes));
            break;
        }
        closesocket(s);
    }
    freeaddrinfo(result);
    return socket_.load() != INVALID_SOCKET;
}

void TcpClient::close() {
    SOCKET s = socket_.exchange(INVALID_SOCKET);
    if (s != INVALID_SOCKET) {
#ifdef _WIN32
        shutdown(s, SD_BOTH);
#else
        shutdown(s, SHUT_RDWR);
#endif
        closesocket(s);
    }
}

bool TcpClient::isConnected() const { return socket_.load() != INVALID_SOCKET; }

bool TcpClient::recvAll(void* data, size_t len) {
    auto* p = static_cast<uint8_t*>(data);
    while (len) {
        const SOCKET s = socket_.load();
        if (s == INVALID_SOCKET) return false;
        const int n = recv(s, reinterpret_cast<char*>(p), static_cast<int>(std::min<size_t>(len, 1 << 20)), 0);
        if (n <= 0) return false;
        p += n;
        len -= static_cast<size_t>(n);
    }
    return true;
}

bool TcpClient::sendAll(const void* data, size_t len) {
    const auto* p = static_cast<const uint8_t*>(data);
    while (len) {
        const SOCKET s = socket_.load();
        if (s == INVALID_SOCKET) return false;
        const int n = ::send(s, reinterpret_cast<const char*>(p), static_cast<int>(std::min<size_t>(len, 1 << 20)), 0);
        if (n <= 0) return false;
        p += n;
        len -= static_cast<size_t>(n);
    }
    return true;
}

bool TcpClient::receive(Packet& packet) {
#pragma pack(push, 1)
    struct Header { uint32_t magic; uint16_t version; uint16_t type; uint32_t flags; uint64_t ts; uint32_t len; uint32_t reserved; };
#pragma pack(pop)
    Header h{};
    if (!recvAll(&h, sizeof(h))) return false;
    if (ntohl(h.magic) != MAGIC || ntohs(h.version) != VERSION) return false;
    const uint32_t len = ntohl(h.len);
    if (len > 32u * 1024u * 1024u) return false;
    packet.type = ntohs(h.type);
    packet.flags = ntohl(h.flags);
    packet.timestamp_ns = ntoh64(h.ts);
    packet.payload.resize(len);
    return len == 0 || recvAll(packet.payload.data(), len);
}

bool TcpClient::send(uint16_t type, uint32_t flags, uint64_t timestampNs, const std::string& payload) {
    std::lock_guard<std::mutex> lock(sendMutex_);
#pragma pack(push, 1)
    struct Header { uint32_t magic; uint16_t version; uint16_t type; uint32_t flags; uint64_t ts; uint32_t len; uint32_t reserved; };
#pragma pack(pop)
    Header h{};
    h.magic = htonl(MAGIC);
    h.version = htons(VERSION);
    h.type = htons(type);
    h.flags = htonl(flags);
    h.ts = hton64(timestampNs);
    h.len = htonl(static_cast<uint32_t>(payload.size()));
    if (!sendAll(&h, sizeof(h))) return false;
    return payload.empty() || sendAll(payload.data(), payload.size());
}

static std::string jsonString(const std::string& json, const char* key) {
    std::regex r(std::string("\\\"") + key + "\\\"\\s*:\\s*\\\"([^\\\"]*)\\\"");
    std::smatch m;
    return std::regex_search(json, m, r) ? m[1].str() : std::string{};
}

static int jsonInt(const std::string& json, const char* key, int fallback) {
    std::regex r(std::string("\\\"") + key + "\\\"\\s*:\\s*([0-9]+)");
    std::smatch m;
    return std::regex_search(json, m, r) ? std::stoi(m[1].str()) : fallback;
}

std::vector<DeviceInfo> discoverDevices(int timeoutMs) {
    std::vector<DeviceInfo> devices;
    SOCKET s = ::socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (s == INVALID_SOCKET) return devices;
    int yes = 1;
    setsockopt(s, SOL_SOCKET, SO_REUSEADDR, reinterpret_cast<const char*>(&yes), sizeof(yes));
    sockaddr_in local{};
    local.sin_family = AF_INET;
    local.sin_addr.s_addr = htonl(INADDR_ANY);
    local.sin_port = htons(48485);
    if (bind(s, reinterpret_cast<sockaddr*>(&local), sizeof(local)) == SOCKET_ERROR) {
        closesocket(s); return devices;
    }
#ifdef _WIN32
    DWORD tv = static_cast<DWORD>(timeoutMs);
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char*>(&tv), sizeof(tv));
#else
    timeval tv{timeoutMs / 1000, (timeoutMs % 1000) * 1000};
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
#endif
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(timeoutMs);
    while (std::chrono::steady_clock::now() < deadline) {
        std::array<char, 2048> buf{};
        sockaddr_in from{};
#ifdef _WIN32
        int fromLen = sizeof(from);
#else
        socklen_t fromLen = sizeof(from);
#endif
        const int n = recvfrom(s, buf.data(), static_cast<int>(buf.size() - 1), 0, reinterpret_cast<sockaddr*>(&from), &fromLen);
        if (n <= 0) break;
        std::string json(buf.data(), static_cast<size_t>(n));
        if (jsonString(json, "service") != "idraiscam") continue;
        char ip[INET_ADDRSTRLEN]{};
        inet_ntop(AF_INET, &from.sin_addr, ip, sizeof(ip));
        DeviceInfo d;
        d.name = jsonString(json, "name");
        d.host = ip;
        d.port = static_cast<uint16_t>(jsonInt(json, "port", 48484));
        const bool duplicate = std::any_of(devices.begin(), devices.end(), [&](const DeviceInfo& x) { return x.host == d.host && x.port == d.port; });
        if (!duplicate) devices.push_back(std::move(d));
    }
    closesocket(s);
    return devices;
}

bool ensureAdbForward(uint16_t port) {
#ifdef _WIN32
    std::string cmd = "cmd.exe /C adb forward tcp:" + std::to_string(port) + " tcp:" + std::to_string(port) + " >nul 2>nul";
    STARTUPINFOA si{}; si.cb = sizeof(si);
    PROCESS_INFORMATION pi{};
    std::vector<char> mutableCmd(cmd.begin(), cmd.end()); mutableCmd.push_back('\0');
    if (!CreateProcessA(nullptr, mutableCmd.data(), nullptr, nullptr, FALSE, CREATE_NO_WINDOW, nullptr, nullptr, &si, &pi)) return false;
    WaitForSingleObject(pi.hProcess, 5000);
    DWORD code = 1; GetExitCodeProcess(pi.hProcess, &code);
    CloseHandle(pi.hThread); CloseHandle(pi.hProcess);
    return code == 0;
#else
    (void)port;
    return false;
#endif
}

}
